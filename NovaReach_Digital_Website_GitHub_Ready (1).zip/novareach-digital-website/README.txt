NOVAREACH DIGITAL — WEBSITE PROJECT
====================================

Fictional company name: NovaReach Digital
Type: Digital marketing agency
Files:
- index.html  (page content and structure)
- style.css   (colors, layout, responsive design)
- script.js   (mobile menu, reveal animations, footer year)

PREVIEW LOCALLY
1. Keep all three files in the same folder.
2. Double-click index.html to open it in a browser.
3. An internet connection is required for the Google Fonts to load; the website itself is static and does not need a server.

PUBLISH WITH GITHUB PAGES
1. Sign in or create a GitHub account at https://github.com/
2. Click the + icon in the top-right corner and choose "New repository".
3. Name the repository: novareach-digital-website
4. Choose Public (typically the simplest option for GitHub Pages on a free account).
5. Create the repository.
6. On the repository page, choose "Add file" > "Upload files".
7. Upload index.html, style.css, and script.js together (not the enclosing folder).
8. Scroll down and click "Commit changes".
9. Open Settings > Pages.
10. Under "Build and deployment", select "Deploy from a branch".
11. Choose branch "main" and folder "/ (root)", then click Save.
12. Wait a few minutes, then refresh Settings > Pages. GitHub will show the published URL, usually:
    https://YOUR-USERNAME.github.io/novareach-digital-website/
13. Open the link and test it on both desktop and mobile. Updates pushed to the main branch are published automatically after a short delay.

EDIT THE WEBSITE ON GITHUB
- Open index.html and click the pencil/edit icon to change wording, service descriptions, links, and section content.
- Open style.css to change colors, fonts, spacing, and layout.
- Open script.js to edit the mobile menu, scroll effects, or footer year behavior.
- Commit your changes; GitHub Pages republishes them automatically.

IMPORTANT CUSTOMIZATION BEFORE PRESENTING
- NovaReach Digital is a fictional demonstration brand.
- The portfolio project cards are sample concepts, not claims of real client work.
- Replace hello@novareachdigital.example in index.html with a real business email. The .example domain is reserved for examples and will not receive mail.
- Add real social links, phone/WhatsApp contact, company address, and verified testimonials/results if available.
- The contact CTA currently opens the visitor's email application via a mailto link; it is not a backend form.
- Sample campaign figures in the dashboard are illustrative, not real performance data.
- If your boss has an actual company name, logo, brand colors, or services, replace the fictional content with the real details before final presentation.
